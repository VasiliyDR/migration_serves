<?php
$sql_migrations = 'CREATE TABLE db_olliver.service_client_test (guid VARCHAR(36) NOT NULL PRIMARY KEY,
type_id int UNSIGNED NOT NULL,
fio VARCHAR(130) NOT NULL,
number VARCHAR(120) NOT NULL,
CONSTRAINT `type_id_to_service_type_client_id` FOREIGN KEY(`type_id`) REFERENCES `service_type_client`(`id`),
);';
$commit_migrations = 'Создание таблицы клиенты сервиса';
?>