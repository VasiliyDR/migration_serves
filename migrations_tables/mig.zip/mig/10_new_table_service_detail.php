<?php
$sql_migrations = 'CREATE TABLE db_olliver.service_detail (id INT UNSIGNED AUTO_INCREMENT NOT NULL PRIMARY KEY, file_link VARCHAR(200) NOT NULL, name VARCHAR(200) NOT NULL);';
$commit_migrations = 'Создание таблицы деталировка';
?>