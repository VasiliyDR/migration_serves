<?php


$sql_migrations = 'CREATE TABLE service_status_in_1C (id INT UNSIGNED AUTO_INCREMENT NOT NULL PRIMARY KEY,
name VARCHAR(50) NOT NULL);';
$commit_migrations = 'Создание таблицы для статусов из 1С';


?>