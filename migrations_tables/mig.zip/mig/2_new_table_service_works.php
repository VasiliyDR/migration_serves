<?php
$sql_migrations = 'CREATE TABLE db_olliver.service_works (id INT UNSIGNED AUTO_INCREMENT NOT NULL PRIMARY KEY, name VARCHAR (50) NOT NULL, price DOUBLE NOT NULL);';
$commit_migrations = 'Создание таблицы работы';
?>