<?php
$sql_migrations = 'CREATE TABLE db_olliver.service_type_broken (id INT UNSIGNED AUTO_INCREMENT NOT NULL PRIMARY KEY, name VARCHAR(120) NOT NULL);';
$commit_migrations = 'Создание таблицы типы неисправностей';
?>