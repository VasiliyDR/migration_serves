<?php
$sql_migrations = 'CREATE TABLE db_olliver.service_spare_parts_test (guid VARCHAR(36) NOT NULL PRIMARY KEY, name VARCHAR(150) NOT NULL, price DOUBLE(8,2) NOT NULL);';
$commit_migrations = 'Создание таблицы запчасти';
?>