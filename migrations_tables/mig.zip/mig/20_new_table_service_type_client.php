<?php
$sql_migrations = 'CREATE TABLE db_olliver.service_type_client_test (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL);';
$commit_migrations = 'Создание таблицы типы клиентов';
?>