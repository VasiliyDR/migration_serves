<?php
$sql_migrations = 'CREATE TABLE service_orders (uid VARCHAR(64) NOT NULL PRIMARY KEY,
                                                                                                        order_name_1c VARCHAR(50),
                                                                                                        employee INT UNSIGNED NOT NULL,
                                                                                                        master INT UNSIGNED NOT NULL, 
                                                                                                        date_create DATETIME DEFAULT CURRENT_TIMESTAMP,
                                                                                                        date_update DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                                                                                                        deadline DATE NOT NULL,
                                                                                                        resource_id INT UNSIGNED NOT NULL, 
                                                                                                        comment TEXT NOT NULL,
                                                                                                        type_order_id INT UNSIGNED NOT NULL,
                                                                                                        prepay BIT DEFAULT 0,
                                                                                                        urgently BIT DEFAULT 0, 
                                                                                                        works_id INT UNSIGNED NOT NULL,
                                                                                                        spare_parts_id INT UNSIGNED NOT NULL,
                                                                                                        workshop_id INT UNSIGNED NOT NULL,
                                                                                                        client_id INT  UNSIGNED NOT NULL,
                                                                                                        device_uid VARCHAR(64) NOT NULL,
                                                                                                        status_id INT UNSIGNED NOT NULL);';
$commit_migrations = 'Создание таблицы заказов для сервиса';
?>