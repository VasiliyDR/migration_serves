<?php
$sql_migrations = 'CREATE TABLE db_olliver.service_source_test (id INT UNSIGNED AUTO_INCREMENT NOT NULL PRIMARY KEY, name VARCHAR(150) NOT NULL);';
$commit_migrations = 'Создание таблицы источника';
?>