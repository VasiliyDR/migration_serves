<?php
$sql_migrations = 'CREATE TABLE db_olliver.service_kit (id INT UNSIGNED AUTO_INCREMENT NOT NULL PRIMARY KEY, name VARCHAR(120) NOT NULL);';
$commit_migrations = 'Создание таблицы комплектации';
?>